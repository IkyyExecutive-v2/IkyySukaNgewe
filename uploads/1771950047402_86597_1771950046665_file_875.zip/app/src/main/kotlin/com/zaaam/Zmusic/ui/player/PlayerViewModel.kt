package com.zaaam.Zmusic.ui.player

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.service.MusicService
import com.zaaam.Zmusic.util.QueueManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    val queueManager: QueueManager
) : ViewModel() {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    // FIX: Track apakah controller sudah siap
    private val _controllerReady = MutableStateFlow(false)

    init {
        connectToService()
        startProgressUpdate()
    }

    private fun connectToService() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicService::class.java)
        )
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            _controllerReady.value = true
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    _isPlaying.value = isPlaying
                    if (isPlaying) _isLoading.value = false
                }

                override fun onPlaybackStateChanged(state: Int) {
                    _isLoading.value = state == Player.STATE_BUFFERING
                    if (state == Player.STATE_ENDED) {
                        _isPlaying.value = false
                        _progress.value = 0f
                    }
                }

                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    _errorMessage.value = "Gagal memutar lagu, coba lagi"
                    _isLoading.value = false
                    _isPlaying.value = false
                }
            })
        }, MoreExecutors.directExecutor())
    }

    private fun startProgressUpdate() {
        viewModelScope.launch {
            while (true) {
                delay(500)
                val ctrl = controller ?: continue
                val duration = ctrl.duration
                val position = ctrl.currentPosition
                if (duration > 0) {
                    _progress.value = position.toFloat() / duration
                    _currentPosition.value = position
                }
            }
        }
    }

    fun playSong(song: Song, queue: List<Song> = listOf(song)) {
        _errorMessage.value = null
        _isLoading.value = true
        queueManager.setQueue(queue, queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0))
        queueManager.requestPlay(song, userInitiated = true)
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
    }

    fun seekTo(fraction: Float) {
        val ctrl = controller ?: return
        val duration = ctrl.duration
        if (duration > 0) ctrl.seekTo((fraction * duration).toLong())
    }

    fun skipNext() {
        val next = queueManager.next() ?: return
        _isLoading.value = true
        queueManager.requestPlay(next, userInitiated = true)
    }

    fun skipPrevious() {
        val ctrl = controller
        if (ctrl != null && ctrl.currentPosition > 3000) {
            ctrl.seekTo(0)
        } else {
            val prev = queueManager.previous() ?: return
            _isLoading.value = true
            queueManager.requestPlay(prev, userInitiated = true)
        }
    }

    fun toggleShuffle() = queueManager.toggleShuffle()

    fun clearError() { _errorMessage.value = null }

    override fun onCleared() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
