package com.zaaam.Zmusic.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaaam.Zmusic.data.MusicRepository
import com.zaaam.Zmusic.model.Song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class HomeContent(
    val greeting: String,
    val featuredSongs: List<Song>,   // horizontal cards (6 pertama)
    val trendingSongs: List<Song>,   // horizontal cards (6 selanjutnya)
    val allSongs: List<Song>         // semua lagu untuk queue
)

sealed class HomeState {
    object Loading : HomeState()
    data class Success(val content: HomeContent) : HomeState()
    data class Error(val message: String) : HomeState()
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    private val _state = MutableStateFlow<HomeState>(HomeState.Loading)
    val state: StateFlow<HomeState> = _state.asStateFlow()

    init {
        loadDiscovery()
    }

    fun loadDiscovery() {
        viewModelScope.launch {
            _state.value = HomeState.Loading
            try {
                val songs = repository.getDiscovery()
                if (songs.isEmpty()) {
                    _state.value = HomeState.Error("Tidak ada konten ditemukan. Coba lagi.")
                } else {
                    val content = HomeContent(
                        greeting = getGreeting(),
                        featuredSongs = songs.take(6),
                        trendingSongs = songs.drop(6).take(8),
                        allSongs = songs
                    )
                    _state.value = HomeState.Success(content)
                }
            } catch (e: Exception) {
                val detail = e.message?.take(100) ?: "Unknown error"
                _state.value = HomeState.Error("Gagal memuat: $detail")
            }
        }
    }

    private fun getGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour < 11 -> "Selamat Pagi"
            hour < 15 -> "Selamat Siang"
            hour < 18 -> "Selamat Sore"
            else -> "Selamat Malam"
        }
    }
}
