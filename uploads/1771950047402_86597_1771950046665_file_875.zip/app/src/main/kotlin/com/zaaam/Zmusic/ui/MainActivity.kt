package com.zaaam.Zmusic.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.ui.about.AboutScreen
import com.zaaam.Zmusic.ui.about.DevScreen
import com.zaaam.Zmusic.ui.components.MiniPlayerBar
import com.zaaam.Zmusic.ui.home.HomeScreen
import com.zaaam.Zmusic.ui.home.HomeViewModel
import com.zaaam.Zmusic.ui.library.LibraryScreen
import com.zaaam.Zmusic.ui.library.LibraryViewModel
import com.zaaam.Zmusic.ui.library.PlaylistDetailScreen
import com.zaaam.Zmusic.ui.library.PlaylistDetailViewModel
import com.zaaam.Zmusic.ui.player.PlayerScreen
import com.zaaam.Zmusic.ui.player.PlayerViewModel
import com.zaaam.Zmusic.ui.search.SearchScreen
import com.zaaam.Zmusic.ui.search.SearchViewModel
import com.zaaam.Zmusic.ui.stats.StatsScreen
import com.zaaam.Zmusic.ui.stats.StatsViewModel
import com.zaaam.Zmusic.ui.theme.ZmusicTheme
import dagger.hilt.android.AndroidEntryPoint

sealed class Screen(val route: String, val label: String) {
    object Home : Screen("home", "Home")
    object Search : Screen("search", "Cari")
    object Library : Screen("library", "Perpustakaan")
    object Stats : Screen("stats", "Statistik")
    object Player : Screen("player", "Player")
    object PlaylistDetail : Screen("playlist/{playlistId}", "Playlist")
    object About : Screen("about", "Tentang")
    object Dev : Screen("dev", "Pengembang")
}

val bottomNavItems = listOf(
    Screen.Home to Icons.Default.Home,
    Screen.Search to Icons.Default.Search,
    Screen.Library to Icons.Default.LibraryMusic,
    Screen.Stats to Icons.Default.ShowChart
)

// Route-route yang menyembunyikan bottom bar
private val hideBottomBarRoutes = setOf(
    Screen.Player.route,
    Screen.About.route,
    Screen.Dev.route
)

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZmusicTheme {
                ZmusicApp()
            }
        }
    }
}

@Composable
fun ZmusicApp() {
    val navController = rememberNavController()
    val playerViewModel: PlayerViewModel = hiltViewModel()
    val libraryViewModel: LibraryViewModel = hiltViewModel()

    val context = LocalContext.current

    val currentQueue by playerViewModel.queueManager.queue.collectAsState()
    val currentIndex by playerViewModel.queueManager.currentIndex.collectAsState()
    val song = currentQueue.getOrNull(currentIndex)
    val isPlaying by playerViewModel.isPlaying.collectAsState()
    val progress by playerViewModel.progress.collectAsState()

    var songToAddToPlaylist by remember { mutableStateOf<Song?>(null) }
    val playlists by libraryViewModel.playlists.collectAsState()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val hideBottomBar = currentDestination?.route in hideBottomBarRoutes

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Column {
                if (song != null && !hideBottomBar) {
                    MiniPlayerBar(
                        currentSong = song,
                        isPlaying = isPlaying,
                        progress = progress,
                        onPlayPauseClick = { playerViewModel.togglePlayPause() },
                        onNextClick = { playerViewModel.skipNext() },
                        onBarClick = { navController.navigate(Screen.Player.route) }
                    )
                }
                if (!hideBottomBar) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ) {
                        bottomNavItems.forEach { (screen, icon) ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.route == screen.route
                            } == true

                            NavigationBarItem(
                                icon = { Icon(icon, screen.label) },
                                label = { Text(screen.label) },
                                selected = selected,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                onClick = {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            composable(Screen.Home.route) {
                val homeViewModel: HomeViewModel = hiltViewModel()
                HomeScreen(
                    viewModel = homeViewModel,
                    onSongClick = { clickedSong, queue ->
                        playerViewModel.playSong(clickedSong, queue)
                        navController.navigate(Screen.Player.route)
                    },
                    onSongLongClick = { clickedSong -> songToAddToPlaylist = clickedSong },
                    onAboutClick = { navController.navigate(Screen.About.route) },
                    onDevPageClick = { navController.navigate(Screen.Dev.route) }
                )
            }

            composable(Screen.Search.route) {
                val searchViewModel: SearchViewModel = hiltViewModel()
                SearchScreen(
                    viewModel = searchViewModel,
                    onSongClick = { clickedSong, queue ->
                        playerViewModel.playSong(clickedSong, queue)
                        navController.navigate(Screen.Player.route)
                    },
                    onSongLongClick = { clickedSong -> songToAddToPlaylist = clickedSong }
                )
            }

            composable(Screen.Library.route) {
                LibraryScreen(
                    viewModel = libraryViewModel,
                    onPlaylistClick = { playlistId ->
                        navController.navigate("playlist/$playlistId")
                    }
                )
            }

            composable(
                route = "playlist/{playlistId}",
                arguments = listOf(navArgument("playlistId") { type = NavType.LongType })
            ) {
                val detailViewModel: PlaylistDetailViewModel = hiltViewModel()
                PlaylistDetailScreen(
                    viewModel = detailViewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onPlayAll = { songs ->
                        if (songs.isNotEmpty()) {
                            playerViewModel.playSong(songs.first(), songs)
                            navController.navigate(Screen.Player.route)
                        }
                    },
                    onShuffleAll = { songs ->
                        if (songs.isNotEmpty()) {
                            val shuffled = songs.shuffled()
                            playerViewModel.playSong(shuffled.first(), shuffled)
                            navController.navigate(Screen.Player.route)
                        }
                    }
                )
            }

            composable(Screen.Stats.route) {
                val statsViewModel: StatsViewModel = hiltViewModel()
                StatsScreen(viewModel = statsViewModel)
            }

            composable(Screen.Player.route) {
                PlayerScreen(
                    viewModel = playerViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.About.route) {
                AboutScreen(
                    onNavigateBack = { navController.popBackStack() },
                    onDevPageClick = { navController.navigate(Screen.Dev.route) }
                )
            }

            composable(Screen.Dev.route) {
                DevScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Dialog: Tambah lagu ke playlist
    songToAddToPlaylist?.let { songToAdd ->
        if (playlists.isEmpty()) {
            AlertDialog(
                onDismissRequest = { songToAddToPlaylist = null },
                title = { Text("Belum Ada Playlist") },
                text = { Text("Buat playlist dulu di tab Perpustakaan.") },
                confirmButton = {
                    TextButton(onClick = {
                        songToAddToPlaylist = null
                        navController.navigate(Screen.Library.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }) { Text("Buat Playlist") }
                },
                dismissButton = {
                    TextButton(onClick = { songToAddToPlaylist = null }) { Text("Batal") }
                }
            )
        } else {
            AlertDialog(
                onDismissRequest = { songToAddToPlaylist = null },
                title = { Text("Tambah ke Playlist") },
                text = {
                    Column {
                        playlists.forEach { playlist ->
                            TextButton(
                                onClick = {
                                    libraryViewModel.addSongToPlaylist(playlist.id, songToAdd)
                                    songToAddToPlaylist = null
                                    Toast.makeText(
                                        context,
                                        "\"${songToAdd.title}\" ditambahkan ke ${playlist.name}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            ) {
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { songToAddToPlaylist = null }) { Text("Batal") }
                }
            )
        }
    }
}
