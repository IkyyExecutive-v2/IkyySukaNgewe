package com.zaaam.Zmusic.data

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NewPipeDownloader @Inject constructor() : Downloader() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun execute(request: Request): Response {
        val requestBuilder = okhttp3.Request.Builder().url(request.url())

        // FIX: headers() returns Map<String, List<String>>
        // Harus iterate tiap value dalam list
        request.headers().forEach { (key, values) ->
            values.forEach { value ->
                requestBuilder.addHeader(key, value)
            }
        }

        val body = request.dataToSend()?.let {
            it.toRequestBody("application/json".toMediaType())
        }

        requestBuilder.method(request.httpMethod(), body)

        val response = client.newCall(requestBuilder.build()).execute()

        // FIX: Response di NewPipeExtractor v0.25.2 tidak punya Builder,
        // pakai constructor langsung:
        // Response(int responseCode, String responseMessage,
        //          Map<String,List<String>> responseHeaders,
        //          String responseBody, String latestUrl)
        return Response(
            response.code,
            response.message,
            response.headers.toMultimap(),
            response.body?.string() ?: "",
            response.request.url.toString()
        )
    }
}
