package com.zaaam.Zmusic.model.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val songId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val playedAt: Long = System.currentTimeMillis(),
    val durationListened: Long
)

data class TopSongResult(
    val songId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val playCount: Int
)

data class TopArtistResult(
    val artist: String,
    val playCount: Int
)
