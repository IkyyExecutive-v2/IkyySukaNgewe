package com.zaaam.Zmusic.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.zaaam.Zmusic.model.entity.PlayHistoryEntity
import com.zaaam.Zmusic.model.entity.TopArtistResult
import com.zaaam.Zmusic.model.entity.TopSongResult
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(history: PlayHistoryEntity)

    @Query("SELECT COUNT(*) FROM play_history")
    fun getTotalPlays(): Flow<Int>

    // FIX: SUM() return NULL saat tabel kosong → crash karena return type non-nullable
    // Gunakan nullable return type agar aman
    @Query("SELECT SUM(durationListened) FROM play_history")
    fun getTotalDuration(): Flow<Long?>

    @Query("""
        SELECT songId, title, artist, thumbnailUrl, COUNT(*) as playCount 
        FROM play_history 
        GROUP BY songId 
        ORDER BY playCount DESC 
        LIMIT :limit
    """)
    fun getTopSongs(limit: Int = 5): Flow<List<TopSongResult>>

    @Query("""
        SELECT artist, COUNT(*) as playCount 
        FROM play_history 
        GROUP BY artist 
        ORDER BY playCount DESC 
        LIMIT :limit
    """)
    fun getTopArtists(limit: Int = 3): Flow<List<TopArtistResult>>
}
