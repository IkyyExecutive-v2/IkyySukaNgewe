package com.zaaam.Zmusic.data

import com.zaaam.Zmusic.data.local.PlayHistoryDao
import com.zaaam.Zmusic.data.local.PlaylistDao
import com.zaaam.Zmusic.data.local.SongDao
import com.zaaam.Zmusic.model.Song
import com.zaaam.Zmusic.model.entity.PlayHistoryEntity
import com.zaaam.Zmusic.model.entity.PlaylistEntity
import com.zaaam.Zmusic.model.entity.PlaylistSongCrossRef
import com.zaaam.Zmusic.model.entity.PlaylistWithSongs
import com.zaaam.Zmusic.model.entity.TopArtistResult
import com.zaaam.Zmusic.model.entity.TopSongResult
import com.zaaam.Zmusic.model.entity.toEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MusicRepository @Inject constructor(
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao,
    private val playHistoryDao: PlayHistoryDao
) {

    // ── NewPipe: Helper ────────────────────────────────────────────────────────

    private fun extractVideoId(url: String): String? =
        Regex("""(?:v=|youtu\.be/|/v/)([\w-]{11})""").find(url)?.groupValues?.get(1)

    private fun StreamInfoItem.toSong(): Song? {
        val videoId = extractVideoId(url) ?: return null
        return Song(
            id = videoId,
            title = name ?: return null,
            artist = uploaderName?.removeSuffix(" - Topic") ?: "Unknown",
            thumbnailUrl = thumbnails.maxByOrNull { it.height }?.url ?: "",
            duration = duration * 1000L
        )
    }

    // ── NewPipe: Search ────────────────────────────────────────────────────────

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
        val searchHandler = youtubeService.searchQHFactory
            .fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), "")
        val searchInfo = SearchInfo.getInfo(youtubeService, searchHandler)

        searchInfo.relatedItems
            .filterIsInstance<StreamInfoItem>()
            .mapNotNull { it.toSong() }
            .distinctBy { it.id }
            .take(20)
    }

    // ── NewPipe: Stream URL ────────────────────────────────────────────────────

    suspend fun getStreamUrl(videoId: String): String = withContext(Dispatchers.IO) {
        val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
        val streamInfo = StreamInfo.getInfo(
            youtubeService,
            "https://www.youtube.com/watch?v=$videoId"
        )

        streamInfo.audioStreams
            .filter { it.content != null }
            .maxByOrNull { it.averageBitrate }
            ?.content
            ?: throw Exception("Tidak ada stream audio tersedia untuk video ini")
    }

    // ── NewPipe: Discovery ─────────────────────────────────────────────────────

    suspend fun getDiscovery(): List<Song> = withContext(Dispatchers.IO) {
        // FIX: Coba Kiosk (Trending) dulu, jika gagal fallback ke search-based discovery.
        // Kiosk sering gagal karena YouTube butuh localization/content country yang tepat.
        // Search-based SELALU berhasil (sudah terbukti di Search screen).
        try {
            val kiosk = getDiscoveryFromKiosk()
            if (kiosk.isNotEmpty()) return@withContext kiosk
        } catch (_: Exception) {
            // Kiosk gagal → langsung fallback ke search
        }

        // Fallback: search beberapa query musik populer dan gabungkan hasilnya
        getDiscoveryFromSearch()
    }

    private suspend fun getDiscoveryFromKiosk(): List<Song> {
        val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
        val kioskList = youtubeService.kioskList

        val kioskId = when {
            "Trending" in kioskList.availableKiosks -> "Trending"
            else -> kioskList.defaultKioskId
        }

        val kioskExtractor = kioskList.getExtractorById(kioskId, null)
        kioskExtractor.fetchPage()

        return kioskExtractor.initialPage.items
            .filterIsInstance<StreamInfoItem>()
            .filter { it.duration in 30..900 }
            .mapNotNull { it.toSong() }
            .distinctBy { it.id }
            .take(30)
    }

    private suspend fun getDiscoveryFromSearch(): List<Song> = coroutineScope {
        // Cari beberapa query populer secara paralel
        val queries = listOf(
            "lagu populer 2025",
            "top hits indonesia",
            "musik trending terbaru"
        )

        val results = queries.map { query ->
            async {
                try {
                    val youtubeService = NewPipe.getService(ServiceList.YouTube.serviceId)
                    val searchHandler = youtubeService.searchQHFactory
                        .fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), "")
                    val searchInfo = SearchInfo.getInfo(youtubeService, searchHandler)

                    searchInfo.relatedItems
                        .filterIsInstance<StreamInfoItem>()
                        .mapNotNull { it.toSong() }
                } catch (_: Exception) {
                    emptyList()
                }
            }
        }.awaitAll()

        results.flatten()
            .distinctBy { it.id }
            .take(30)
    }

    // ── Playlist ───────────────────────────────────────────────────────────────

    suspend fun createPlaylist(name: String): Long =
        playlistDao.insert(PlaylistEntity(name = name))

    suspend fun addToPlaylist(playlistId: Long, song: Song) {
        songDao.insertOrIgnore(song.toEntity())
        val position = playlistDao.getSongCount(playlistId)
        playlistDao.addSong(PlaylistSongCrossRef(playlistId, song.id, position))
    }

    suspend fun removeFromPlaylist(playlistId: Long, songId: String) =
        playlistDao.removeSong(playlistId, songId)

    fun getAllPlaylists(): Flow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()

    fun getPlaylistWithSongs(playlistId: Long): Flow<PlaylistWithSongs> =
        playlistDao.getPlaylistWithSongs(playlistId)

    suspend fun deletePlaylist(playlistId: Long) = playlistDao.delete(playlistId)

    // ── Play History / Stats ───────────────────────────────────────────────────

    suspend fun recordPlay(song: Song, durationListened: Long) {
        if (durationListened < 10_000) return  // minimal 10 detik
        playHistoryDao.insert(
            PlayHistoryEntity(
                songId = song.id,
                title = song.title,
                artist = song.artist,
                thumbnailUrl = song.thumbnailUrl,
                durationListened = durationListened
            )
        )
    }

    fun getTotalPlays(): Flow<Int> = playHistoryDao.getTotalPlays()

    fun getTotalDuration(): Flow<Long?> = playHistoryDao.getTotalDuration()

    fun getTopSongs(limit: Int = 5): Flow<List<TopSongResult>> =
        playHistoryDao.getTopSongs(limit)

    fun getTopArtists(limit: Int = 3): Flow<List<TopArtistResult>> =
        playHistoryDao.getTopArtists(limit)
}
